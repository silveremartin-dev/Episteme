The Open Dynamics Engine (ODE)
==============================

![ODE logo](https://bitbucket.org/odedevs/ode/raw/master/web/ODElogo.png)

Copyright (C) 2001-2007 Russell L. Smith.


ODE is a free, industrial quality library for simulating articulated
rigid body dynamics - for example ground vehicles, legged creatures,
and moving objects in VR environments. It is fast, flexible, robust
and platform independent, with advanced joints, contact with friction,
and built-in collision detection.

This library is free software; you can redistribute it and/or
modify it under the terms of EITHER:

 * The GNU Lesser General Public License version 2.1 or any later.

 * The BSD-style License.

See the [COPYING](https://bitbucket.org/odedevs/ode/raw/master/COPYING) file for more details.

 * Installation instructions are in the [INSTALL.txt](https://bitbucket.org/odedevs/ode/raw/master/INSTALL.txt) file.

 * The ODE web pages are at [ode.org](https://www.ode.org/).

 * An online manual is at [the Wiki](https://ode.org/wiki/index.php?title=Manual).

 * API documentation is in the file ode/docs/index.html, or you
   can view it on the web at [opende.sf.net/docs/index.html](http://opende.sf.net/docs/index.html).

 * Coding style requirements can be found in the [CSR.txt](https://bitbucket.org/odedevs/ode/raw/master/CSR.txt) file.

